﻿using System;

namespace WebSite.Account
{
    public partial class ChangePassword
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}
